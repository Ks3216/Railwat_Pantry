# Railway-Pantry-Management

The Indian Railway Pantry Management is an intuitively initiated project, being Indian citizens and train travelers, who have experienced the prevailing pantry system and the way it functions and provides customer service.

The project is all about the proper and reliable functioning of the chain of Indian Railway Pantries in a more systematic, organized and customer satisfying way. The model would be a dynamically working website that would provide the service of placing food orders, to the passengers who travel in a train within few taps or clicks via their smartphones, tabs, laptops, etc.

*The system is made Using HTML, CSS, JavaScipt, PHP and MySQL*

### Sample Screenshots

![image](https://user-images.githubusercontent.com/67074796/123333668-a910ec00-d55f-11eb-8dde-206a3783194a.png)


![image](https://user-images.githubusercontent.com/67074796/123333750-c5148d80-d55f-11eb-8879-e3f33685cab8.png)
