<?php session_start(); ?>
<html>
    <head>
        <title>Payment Home</title>
        <link rel="stylesheet" href="css/main_payment_gateway.css">
    </head>
    <body>
        <h1 align="center">Select a Payment Mode</h1>
        <br>
        <br>
        <br>
        <br>
        <center><a href="payment.php" style="text-decoration: none; color: darkred;
        font-weight: bold; font-size: 30px;" class="btn">Debit Card/ATM Card</a><br><br><br><br><br><br><br><br>
        <a href="payment.php" style="text-decoration: none; color: darkred; font-weight: bold; font-size: 30px;" class="btn">Credit Card</a><br><br><br><br><br><br><br><br><a href="cod.php"
        style="text-decoration: none; color: darkred; font-weight: bold; font-size: 30px;" class="btn">Cash On Delivery</a></center>
    </body>
</html>
